<?php
declare(strict_types=1);

return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'nexora',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'name' => 'Nexora',
        'base_url' => '', // مثال: /nexora/public — برای نصب در ریشه خالی بماند
        'session_name' => 'nexora_session',
    ],
];
