CREATE DATABASE IF NOT EXISTS nexora CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nexora;

CREATE TABLE IF NOT EXISTS admins (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS settings (
  setting_key VARCHAR(100) PRIMARY KEY,
  setting_value TEXT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sections (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  section_key VARCHAR(80) NOT NULL UNIQUE,
  title VARCHAR(180) NOT NULL,
  eyebrow VARCHAR(180) DEFAULT '',
  body TEXT,
  button_text VARCHAR(100) DEFAULT '',
  button_url VARCHAR(255) DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO settings (setting_key, setting_value) VALUES
('brand_name','Nexora'),('tagline','ایده‌های بزرگ، تجربه‌های دیجیتال ماندگار'),
('accent_color','#ff6b35'),('email','hello@example.com'),
('phone','021-12345678'),('address','تهران، ایران'),
('instagram_url','#'),('linkedin_url','#');

INSERT IGNORE INTO sections (section_key,title,eyebrow,body,button_text,button_url,sort_order,is_active) VALUES
('hero','از ایده تا تجربه‌ای متفاوت','استودیو دیجیتال نسل جدید','ما به برندها کمک می‌کنیم با طراحی، فناوری و استراتژی، تجربه‌هایی متمایز بسازند.','شروع همکاری','#contact',1,1),
('services','خدماتی برای رشد واقعی','چه کاری انجام می‌دهیم؟','طراحی تجربه کاربری، توسعه وب‌سایت و راهکارهای دیجیتال متناسب با اهداف کسب‌وکار شما.','مشاهده خدمات','#contact',2,1),
('work','کارهایی که حرف می‌زنند','نمونه‌کارها','ترکیبی از نگاه استراتژیک، طراحی دقیق و اجرای فنی برای ساخت محصولاتی که به‌یاد می‌مانند.','گفت‌وگو درباره پروژه','#contact',3,1),
('about','همراه شما در مسیر تحول','درباره ما','از شناخت مسئله تا ارائه راهکار، کنار تیم شما هستیم تا ایده‌ها به نتیجه‌ای ملموس تبدیل شوند.','','',4,1),
('contact','بیایید چیزی ارزشمند بسازیم','قدم بعدی با شماست','پروژه‌ای در ذهن دارید؟ درباره هدف‌هایتان بگویید تا مسیر مناسب را پیدا کنیم.','ارسال ایمیل','mailto:hello@example.com',5,1);
