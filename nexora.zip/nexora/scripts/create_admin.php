<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/Core/Database.php';
use App\Core\Database;

$username = $argv[1] ?? 'admin';
if (PHP_SAPI !== 'cli') { exit("این اسکریپت فقط از خط فرمان اجرا می‌شود.\n"); }
echo "رمز مدیر را وارد کنید (حداقل 12 نویسه): ";
$line = trim((string)fgets(STDIN));
if (strlen($line) < 12) exit("رمز باید حداقل 12 نویسه باشد.\n");
$pdo = Database::connection();
$stmt = $pdo->prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?) ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash)');
$stmt->execute([$username, password_hash($line, PASSWORD_DEFAULT)]);
echo "مدیر «{$username}» ساخته/به‌روزرسانی شد.\n";
