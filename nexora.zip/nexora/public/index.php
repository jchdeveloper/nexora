<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/Core/bootstrap.php';
use App\Core\Database;
use App\Core\Security;
require_once __DIR__.'/section-renderer.php';
$pdo = Database::connection();
try { $pdo->exec("CREATE TABLE IF NOT EXISTS page_views (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, path VARCHAR(255) NOT NULL, viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX viewed_at_idx(viewed_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); $view=$pdo->prepare('INSERT INTO page_views(path) VALUES(?)'); $view->execute([parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/']); } catch (Throwable $e) { /* analytics must not interrupt public pages */ }
$settings = [];
foreach ($pdo->query('SELECT setting_key, setting_value FROM settings') as $row) $settings[$row['setting_key']] = $row['setting_value'];
$sections = $pdo->query('SELECT * FROM sections WHERE is_active = 1 ORDER BY sort_order, id')->fetchAll();
$publishedPosts = [];
try { $publishedPosts = $pdo->query("SELECT id,title,slug,body,created_at,category,featured_image FROM content_items WHERE type='post' AND status='published' ORDER BY created_at DESC LIMIT 100")->fetchAll(); } catch (Throwable $e) { /* content table may not be installed yet */ }
$brand = $settings['brand_name'] ?? 'Nexora';
$accent = $settings['accent_color'] ?? '#ff6b35';
$secondary = $settings['secondary_color'] ?? '#7c5cff';
$background = $settings['background_color'] ?? '#c7fff8';
$bgRgb = preg_match('/^#[0-9a-fA-F]{6}$/', $background) ? [hexdec(substr($background,1,2)),hexdec(substr($background,3,2)),hexdec(substr($background,5,2))] : [9,9,9];
$bgLight = (($bgRgb[0]*299 + $bgRgb[1]*587 + $bgRgb[2]*114)/1000) > 145;
$textColor = $bgLight ? '#171717' : '#f5f2ef';
$mutedColor = $bgLight ? '#5b5b5b' : '#aaa';
$logoPath = trim((string)($settings['logo_path'] ?? ''));
$showBrandName = (($settings['header_brand_mode'] ?? 'logo') === 'name' || $logoPath === '');
try { $pdo->exec("CREATE TABLE IF NOT EXISTS social_networks (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, username_or_url VARCHAR(500) NOT NULL, icon_path VARCHAR(255) NOT NULL DEFAULT '', sort_order INT NOT NULL DEFAULT 10, is_active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); try{$pdo->exec("ALTER TABLE social_networks ADD COLUMN url_prefix VARCHAR(255) NOT NULL DEFAULT ''");}catch(Throwable $e){} $customSocials=$pdo->query('SELECT * FROM social_networks WHERE is_active=1 ORDER BY sort_order,id')->fetchAll(); } catch (Throwable $e) { $customSocials=[]; }
$showBrandName = (($settings['header_brand_mode'] ?? 'logo') === 'name' || $logoPath === '');
try { $pdo->exec("CREATE TABLE IF NOT EXISTS social_networks (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, username_or_url VARCHAR(500) NOT NULL, icon_path VARCHAR(255) NOT NULL DEFAULT '', sort_order INT NOT NULL DEFAULT 10, is_active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"); try{$pdo->exec("ALTER TABLE social_networks ADD COLUMN url_prefix VARCHAR(255) NOT NULL DEFAULT ''");}catch(Throwable $e){} $customSocials=$pdo->query('SELECT * FROM social_networks WHERE is_active=1 ORDER BY sort_order,id')->fetchAll(); } catch (Throwable $e) { $customSocials=[]; }
$faviconPath = trim((string)($settings['favicon_path'] ?? $logoPath));
$chatColor = $settings['chat_button_color'] ?? $accent;
$chatStart = $settings['chat_button_gradient_start'] ?? $accent;
$chatEnd = $settings['chat_button_gradient_end'] ?? $secondary;
$socialLinks=[];
foreach($customSocials as $sn){$v=ltrim(trim((string)$sn['username_or_url']),'@/');$n=mb_strtolower(trim((string)$sn['name']),'UTF-8');$prefixes=['instagram'=>'https://instagram.com/','اینستاگرام'=>'https://instagram.com/','linkedin'=>'https://www.linkedin.com/in/','لینکدین'=>'https://www.linkedin.com/in/','telegram'=>'https://t.me/','تلگرام'=>'https://t.me/','rubika'=>'https://rubika.ir/','روبیکا'=>'https://rubika.ir/','eitaa'=>'https://eitaa.com/','ایتا'=>'https://eitaa.com/','bale'=>'https://ble.ir/','بله'=>'https://ble.ir/','whatsapp'=>'https://wa.me/','واتساپ'=>'https://wa.me/','youtube'=>'https://youtube.com/@','یوتیوب'=>'https://youtube.com/@','aparat'=>'https://www.aparat.com/','آپارات'=>'https://www.aparat.com/','x'=>'https://x.com/','ایکس'=>'https://x.com/'];$base=trim((string)($sn['url_prefix']??''));if($base!=='' && substr($base,-1)!=='/')$base.='/';$url=preg_match('~^https?://~i',$v)?$v:((($base!=='')?$base:($prefixes[$n]??''))!==''?(($base!=='')?$base:($prefixes[$n]??'')).$v:'');if($url && filter_var($url,FILTER_VALIDATE_URL))$socialLinks[]=[(string)$sn['name'],$url,(string)$sn['icon_path']];}
$navSections = array_slice(array_values(array_filter($sections, static fn($s) => ($s['section_key'] ?? '') !== 'hero')), 0, 6); // خانه + حداکثر ۶ سکشن = ۷ لینک
function setting(array $s, string $k, string $default=''): string { return htmlspecialchars($s[$k] ?? $default, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#090909"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><link rel="manifest" href="manifest.webmanifest"><link rel="apple-touch-icon" href="assets/pwa/icon-192.png">
<title><?= setting($settings,'brand_name','Nexora') ?> — <?= setting($settings,'tagline','تجربه‌ای متفاوت') ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/site.css"><link rel="stylesheet" href="assets/css/navigation-fix.css"><link rel="stylesheet" href="assets/css/brand-theme.css"><?php if($faviconPath!==''): ?><link rel="icon" href="<?= setting($settings,'favicon_path',$faviconPath) ?>"><?php endif; ?>
<style>:root{--accent:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$accent)?$accent:'#ff6b35' ?>;--secondary:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$secondary)?$secondary:'#7c5cff' ?>;--site-bg:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$background)?$background:'#090909' ?>;--text-color:<?= $textColor ?>;--muted-color:<?= $mutedColor ?>;--chat-button-color:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$chatColor)?$chatColor:'#ff6b35' ?>;--chat-gradient-start:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$chatStart)?$chatStart:'#ff6b35' ?>;--chat-gradient-end:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$chatEnd)?$chatEnd:'#7c5cff' ?>}</style>
</head>
<body>
<header class="site-header"><a class="brand" href="#top"><?php if(!$showBrandName && $logoPath!==''): ?><img class="brand-logo" src="<?= setting($settings,'logo_path') ?>" alt="<?= setting($settings,'brand_name','Nexora') ?>"><?php else: ?><?= setting($settings,'brand_name','Nexora') ?><?php endif; ?></a><button class="menu-toggle" aria-expanded="false" aria-label="باز کردن منو">☰</button>
<nav class="main-nav"><a href="#top" aria-label="خانه">خانه</a><?php foreach($navSections as $s): ?><a href="#<?= Security::e($s['section_key']) ?>"><?= Security::e($s['title']) ?></a><?php endforeach; ?></nav><a class="header-cta" href="#contact">شروع گفتگو ↗</a></header>
<main id="top">
<?php foreach($sections as $i=>$s): nexora_render_section($s,$i,$settings,$publishedPosts); endforeach; ?>
<?php /* Latest posts are rendered at their sortable section position. */ ?>
<?php /* old block removed */ ?>
<?php if (false): ?>
<section id="articles" class="posts-section"><div class="posts-inner"><p class="eyebrow">مطالب تازه</p><h2>آخرین نوشته‌ها</h2><div class="posts-grid"><?php foreach ($publishedPosts as $post): ?><article class="post-card"><?php if(!empty($post['featured_image'])): ?><a href="post.php?slug=<?= rawurlencode((string)$post['slug']) ?>"><img class="post-featured-image" src="<?= Security::e((string)$post['featured_image']) ?>" alt="<?= Security::e((string)$post['title']) ?>" loading="lazy"></a><?php endif; ?><?php if(!empty($post['category'])): ?><span class="post-category"><?= Security::e((string)$post['category']) ?></span><?php endif; ?><p class="post-date"><?= Security::e(\App\Core\DateHelper::jalali($post['created_at'], false)) ?></p><h3><a class="post-title-link" href="post.php?slug=<?= rawurlencode((string)$post['slug']) ?>"><?= Security::e($post['title']) ?></a></h3><p><?= nl2br(Security::e(mb_strimwidth(strip_tags((string)$post['body']), 0, 220, '…', 'UTF-8'))) ?></p><a class="read-more" href="post.php?slug=<?= rawurlencode((string)$post['slug']) ?>">ادامه مطلب <span aria-hidden="true">←</span></a></article><?php endforeach; ?></div></div></section>
<?php endif; ?>
</main>
<footer><div><strong><?php if($logoPath!==''): ?><img class="footer-logo" src="<?= setting($settings,'logo_path') ?>" alt="<?= setting($settings,'brand_name','Nexora') ?>"><?php else: ?><?= setting($settings,'brand_name','Nexora') ?><?php endif; ?></strong><p><?= setting($settings,'tagline') ?></p></div><div class="footer-contact"><a href="mailto:<?= setting($settings,'email','hello@example.com') ?>"><?= setting($settings,'email','hello@example.com') ?></a><span><?= setting($settings,'phone') ?></span><span><?= setting($settings,'address') ?></span></div><?php if($socialLinks): ?><div class="footer-socials" aria-label="شبکه‌های اجتماعی"><?php foreach($socialLinks as [$socialName,$socialUrl,$socialIcon]): ?><a href="<?= Security::e($socialUrl) ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= Security::e($socialName) ?>" title="<?= Security::e($socialName) ?>"><?php if($socialIcon!==''): ?><img class="social-icon-image" src="<?= Security::e($socialIcon) ?>" alt="" loading="lazy"><?php else: ?><span class="social-icon social-<?= strtolower(preg_replace('/[^a-zA-Z0-9]+/','-',$socialName)) ?>" aria-hidden="true"><?= ['Instagram'=>'◎','LinkedIn'=>'in','Telegram'=>'➤','Rubika'=>'ر','Eitaa'=>'ا','Bale'=>'ب','WhatsApp'=>'◉','YouTube'=>'▶','Aparat'=>'▣','X'=>'𝕏'][$socialName] ?? '•' ?></span><?php endif; ?></a><?php endforeach; ?></div><?php endif; ?><small>© <span id="year"></span> — تمام حقوق محفوظ است.</small></footer>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script><script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/ScrollTrigger.min.js"></script><script src="https://cdn.jsdelivr.net/npm/lenis@1.1.18/dist/lenis.min.js"></script><script src="assets/js/site.js"></script><script src="assets/js/pwa.js"></script>
</body></html>
