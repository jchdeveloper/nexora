<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/Core/bootstrap.php';
require_once dirname(__DIR__) . '/app/Core/DateHelper.php';
use App\Core\Database;
use App\Core\Security;
use App\Core\DateHelper;
$pdo = Database::connection();
$slug = trim((string)($_GET['slug'] ?? ''));
$stmt = $pdo->prepare("SELECT id,title,slug,body,created_at,updated_at,category,featured_image,seo_title,seo_description FROM content_items WHERE type='post' AND status='published' AND slug=? LIMIT 1");
$stmt->execute([$slug]);
$post = $stmt->fetch();
if (!$post) http_response_code(404);
$settings = [];
try { foreach ($pdo->query('SELECT setting_key,setting_value FROM settings') as $row) $settings[$row['setting_key']] = $row['setting_value']; } catch (Throwable $e) {}
$navSections = [];
try { $allSections = $pdo->query('SELECT section_key,title FROM sections WHERE is_active=1 ORDER BY sort_order,id')->fetchAll(); $navSections = array_slice(array_values(array_filter($allSections, static fn($s) => ($s['section_key'] ?? '') !== 'hero')), 0, 7); } catch (Throwable $e) {}
$brand = (string)($settings['brand_name'] ?? 'Nexora');
$accent = (string)($settings['accent_color'] ?? '#ff6b35');
$secondary = (string)($settings['secondary_color'] ?? '#7c5cff');
$background = (string)($settings['background_color'] ?? '#090909');
$bgRgb = preg_match('/^#[0-9a-fA-F]{6}$/', $background) ? [hexdec(substr($background,1,2)),hexdec(substr($background,3,2)),hexdec(substr($background,5,2))] : [9,9,9];
$bgLight = (($bgRgb[0]*299 + $bgRgb[1]*587 + $bgRgb[2]*114)/1000) > 145;
$textColor = $bgLight ? '#171717' : '#f5f2ef';
$mutedColor = $bgLight ? '#5b5b5b' : '#aaa';
$logoPath = trim((string)($settings['logo_path'] ?? ''));
$faviconPath = trim((string)($settings['favicon_path'] ?? $logoPath));
$ctaText = (string)($settings['header_cta_text'] ?? 'شروع گفتگو ↗');
$ctaUrl = (string)($settings['header_cta_url'] ?? '#contact');
function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function settingValue(array $s, string $key, string $default=''): string { return e((string)($s[$key] ?? $default)); }
function navUrl(string $url): string {
    $url = trim($url);
    if (preg_match('/^\s*(javascript|data|vbscript):/i', $url)) return '#';
    if (str_starts_with($url, '#')) return 'index.php' . $url;
    return $url;
}
$related = [];
if ($post) {
    $rel = $pdo->prepare("SELECT title,slug,body,created_at,category,featured_image FROM content_items WHERE type='post' AND status='published' AND id<>? ORDER BY created_at DESC LIMIT 3");
    $rel->execute([(int)$post['id']]);
    $related = $rel->fetchAll();
}
?><!doctype html>
<html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#090909">
<title><?= $post ? e((string)((($post['seo_title']??'') ?: $post['title']).' — '.$brand)) : 'نوشته پیدا نشد — '.e($brand) ?></title>
<meta name="description" content="<?= $post ? e((string)(($post['seo_description']??'') ?: mb_strimwidth(strip_tags((string)$post['body']),0,155,'…','UTF-8'))) : 'نوشته مورد نظر پیدا نشد.' ?>">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/site.css"><link rel="stylesheet" href="assets/css/manual-navigation.css"><link rel="stylesheet" href="assets/css/brand-theme.css"><?php if($faviconPath!==''): ?><link rel="icon" href="<?= settingValue($settings,'favicon_path',$faviconPath) ?>"><?php endif; ?>
<style>:root{--accent:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$accent)?$accent:'#ff6b35' ?>;--secondary:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$secondary)?$secondary:'#7c5cff' ?>;--site-bg:<?= preg_match('/^#[0-9a-fA-F]{6}$/',$background)?$background:'#090909' ?>;--text-color:<?= $textColor ?>;--muted-color:<?= $mutedColor ?>}</style></head><body>
<header class="site-header"><a class="brand" href="index.php#top"><?php if($logoPath!==''): ?><img class="brand-logo" src="<?= settingValue($settings,'logo_path') ?>" alt="<?= e($brand) ?>"><?php else: ?><?= e($brand) ?><span>●</span><?php endif; ?></a><button class="menu-toggle" aria-expanded="false" aria-label="باز کردن منو">☰</button><nav class="main-nav"><a href="index.php#top" aria-label="خانه">خانه</a><?php foreach($navSections as $section): ?><a href="index.php#<?= e((string)$section['section_key']) ?>"><?= e((string)$section['title']) ?></a><?php endforeach; ?></nav><a class="header-cta" href="<?= e(navUrl($ctaUrl)) ?>"><?= e($ctaText) ?></a></header>
<main class="article-main">
<?php if (!$post): ?><section class="article-not-found"><p class="eyebrow">خطای ۴۰۴</p><h1>این نوشته پیدا نشد</h1><p class="lead">ممکن است نوشته حذف شده باشد یا هنوز منتشر نشده باشد.</p><a class="button" href="index.php#articles">بازگشت به نوشته‌ها</a></section>
<?php else: ?><article class="article-detail"><a class="article-back" href="index.php#articles">← بازگشت به نوشته‌ها</a><p class="eyebrow">نوشته / <?= e(DateHelper::jalali((string)$post['created_at'], false)) ?></p><h1><?= e((string)$post['title']) ?></h1><?php if(!empty($post['category'])): ?><p class="post-category"><?= e((string)$post['category']) ?></p><?php endif; ?><?php if(!empty($post['featured_image'])): ?><img class="article-featured-image" src="<?= e((string)$post['featured_image']) ?>" alt="<?= e((string)$post['title']) ?>"><?php endif; ?><div class="article-meta">منتشرشده در <?= e(DateHelper::jalali((string)$post['created_at'], false)) ?></div><div class="article-content"><?= nl2br(e((string)$post['body'])) ?></div></article>
<?php if ($related): ?><section class="related-posts"><p class="eyebrow">برای مطالعه بیشتر</p><h2>نوشته‌های مرتبط</h2><div class="posts-grid"><?php foreach ($related as $item): ?><article class="post-card"><?php if(!empty($item['featured_image'])): ?><a href="post.php?slug=<?= rawurlencode((string)$item['slug']) ?>"><img class="post-featured-image" src="<?= e((string)$item['featured_image']) ?>" alt="<?= e((string)$item['title']) ?>" loading="lazy"></a><?php endif; ?><p class="post-date"><?= e(DateHelper::jalali((string)$item['created_at'], false)) ?></p><h3><a class="post-title-link" href="post.php?slug=<?= rawurlencode((string)$item['slug']) ?>"><?= e((string)$item['title']) ?></a></h3><p><?= e(mb_strimwidth(strip_tags((string)$item['body']),0,150,'…','UTF-8')) ?></p><a class="read-more" href="post.php?slug=<?= rawurlencode((string)$item['slug']) ?>">ادامه مطلب ←</a></article><?php endforeach; ?></div></section><?php endif; ?><?php endif; ?>
</main><footer><div><strong><?php if($logoPath!==''): ?><img class="footer-logo" src="<?= settingValue($settings,'logo_path') ?>" alt="<?= e($brand) ?>"><?php else: ?><?= e($brand) ?><?php endif; ?></strong><p><?= settingValue($settings,'tagline') ?></p></div><div class="footer-contact"><a href="mailto:<?= settingValue($settings,'email','hello@example.com') ?>"><?= settingValue($settings,'email','hello@example.com') ?></a><span><?= settingValue($settings,'phone') ?></span><span><?= settingValue($settings,'address') ?></span></div><small>© <?= date('Y') ?> — تمام حقوق محفوظ است.</small></footer>
<script>(function(){var b=document.querySelector(".menu-toggle"),n=document.querySelector(".main-nav");if(!b||!n)return;b.addEventListener("click",function(){var o=b.getAttribute("aria-expanded")==="true";b.setAttribute("aria-expanded",String(!o));n.classList.toggle("is-open",!o)});n.querySelectorAll("a").forEach(function(a){a.addEventListener("click",function(){b.setAttribute("aria-expanded","false");n.classList.remove("is-open")})})})();</script></body></html>
