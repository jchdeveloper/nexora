<?php
function nexora_section_schema(PDO $pdo): void {
 $columns = [
  'section_type' => "VARCHAR(32) NOT NULL DEFAULT 'text'",
  'section_data' => 'MEDIUMTEXT NULL',
  'image_path' => 'VARCHAR(255) NULL',
  'background_color' => "VARCHAR(7) NOT NULL DEFAULT ''",
  'padding_top' => 'SMALLINT NOT NULL DEFAULT 80',
  'padding_bottom' => 'SMALLINT NOT NULL DEFAULT 80',
  'mobile_data' => 'TEXT NULL',
  'layout_mode' => "VARCHAR(20) NOT NULL DEFAULT 'preset'",
  'custom_html' => 'MEDIUMTEXT NULL'
 ];
 $existing=[]; foreach($pdo->query('SHOW COLUMNS FROM sections') as $c) $existing[$c['Field']]=true;
 foreach($columns as $name=>$definition) if(!isset($existing[$name])) $pdo->exec("ALTER TABLE sections ADD COLUMN `$name` $definition");
 // Repair legacy latest-posts section type so the section renderer keeps displaying post cards.
 $repair=$pdo->prepare("UPDATE sections SET section_type='posts' WHERE section_key IN ('latest-posts','articles') AND section_type<>'posts'"); $repair->execute();
 // Add a dedicated, editable latest-posts section once; existing post records remain untouched.
 $check=$pdo->prepare('SELECT id FROM sections WHERE section_key=? LIMIT 1'); $check->execute(['latest-posts']);
 if(!$check->fetchColumn()) { $max=(int)$pdo->query('SELECT COALESCE(MAX(sort_order),0) FROM sections')->fetchColumn(); $q=$pdo->prepare("INSERT INTO sections(section_key,title,eyebrow,body,button_text,button_url,sort_order,is_active,section_type,section_data,image_path,background_color,padding_top,padding_bottom,mobile_data,layout_mode,custom_html) VALUES(?,?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?)"); $q->execute(['latest-posts','آخرین نوشته‌ها','مطالب تازه','جدیدترین مطالب وب‌سایت','','', $max+1,'posts',json_encode(['posts_mode'=>'auto','posts_count'=>6,'gradient_color_1'=>'#c7fff8','gradient_color_2'=>'#c7fff8','gradient_type'=>'linear','gradient_angle'=>135,'media_type'=>'image','media_side'=>'left'],JSON_UNESCAPED_UNICODE),'','#c7fff8',64,64,'{}','preset','']); }
}
