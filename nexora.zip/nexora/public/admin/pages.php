<?php
$contentType='page'; require __DIR__.'/content-manager.php';
