<?php
require_once __DIR__.'/_init.php';
$type=$contentType==='page'?'page':'post'; $label=$type==='page'?'برگه':'نوشته'; $file=$type==='page'?'pages.php':'posts.php'; $success='';$error='';$action=(string)($_GET['action']??'');$id=(int)($_GET['id']??$_POST['id']??0);
$pdo->exec("CREATE TABLE IF NOT EXISTS post_categories (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, slug VARCHAR(160) NOT NULL UNIQUE, parent_id INT UNSIGNED NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (parent_id) REFERENCES post_categories(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$pdo->exec("ALTER TABLE content_items ADD COLUMN IF NOT EXISTS category_id INT UNSIGNED NULL");
$uploadDir=dirname(__DIR__).'/uploads/posts/';
$uploadUrl='../uploads/posts/';
if(!is_dir($uploadDir)) @mkdir($uploadDir,0755,true);
if($_SERVER['REQUEST_METHOD']==='POST'){
 \App\Core\Security::verifyCsrf(); $do=(string)($_POST['do']??'save');
 if($do==='add_category'){
 $n=trim((string)($_POST['new_category_name']??'')); $parent=(int)($_POST['new_category_parent']??0);
 if($n!==''){ $slug=preg_replace('/[^\pL\pN]+/u','-',mb_strtolower($n)) ?: 'category-'.time(); try{$q=$pdo->prepare('INSERT INTO post_categories(name,slug,parent_id) VALUES(?,?,?)');$q->execute([$n,$slug,$parent?:null]);$success='دسته‌بندی ساخته شد.';}catch(PDOException $ex){$error='این نامک دسته‌بندی قبلاً استفاده شده است.';} }
 else $error='نام دسته‌بندی را وارد کن.';
 $action=(string)($_POST['return_action']??'new'); $id=(int)($_POST['id']??0);
 } elseif($do==='delete'){ $st=$pdo->prepare('DELETE FROM content_items WHERE id=? AND type=?');$st->execute([$id,$type]);header('Location: '.$file.'?deleted=1');exit; }
 $title=trim((string)($_POST['title']??''));$slug=trim((string)($_POST['slug']??''));$body=trim((string)($_POST['body']??''));$status=($_POST['status']??'draft')==='published'?'published':'draft';
 $categoryId=(int)($_POST['category_id']??0);$category='';if($categoryId){$cq=$pdo->prepare('SELECT name FROM post_categories WHERE id=?');$cq->execute([$categoryId]);$category=(string)($cq->fetchColumn()?:'');}$seoTitle=trim((string)($_POST['seo_title']??''));$seoDescription=trim((string)($_POST['seo_description']??''));$featuredImage=trim((string)($_POST['featured_image_existing']??''));
 if(!empty($_FILES['featured_image']['name']) && is_uploaded_file($_FILES['featured_image']['tmp_name'])){
   $f=$_FILES['featured_image']; $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
   $mime=function_exists('mime_content_type')?mime_content_type($f['tmp_name']):($f['type']??'');
   if(($f['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK){$error='بارگذاری تصویر ناموفق بود.';}
   elseif(!isset($allowed[$mime])){$error='فقط تصویرهای JPG، PNG، WebP یا GIF مجاز هستند.';}
   elseif(($f['size']??0)>5*1024*1024){$error='حجم تصویر باید کمتر از ۵ مگابایت باشد.';}
   else{$filename=bin2hex(random_bytes(12)).'.'.$allowed[$mime];if(move_uploaded_file($f['tmp_name'],$uploadDir.$filename))$featuredImage='uploads/posts/'.$filename;else $error='ذخیره تصویر روی سرور انجام نشد.';}
 }
 if($title==='')$error='عنوان را وارد کنید.';
 if(!$error){
  if($slug==='')$slug='content-'.time();$slug=preg_replace('/[^\pL\pN\-_]+/u','-',$slug)?:('content-'.time());
  try{
   if($id){$st=$pdo->prepare('UPDATE content_items SET title=?,slug=?,body=?,status=?,category=?,category_id=?,featured_image=?,seo_title=?,seo_description=? WHERE id=? AND type=?');$st->execute([$title,$slug,$body,$status,$category,$categoryId?:null,$featuredImage,$seoTitle,$seoDescription,$id,$type]);}
   else{$st=$pdo->prepare('INSERT INTO content_items(type,title,slug,body,status,category,category_id,featured_image,seo_title,seo_description) VALUES(?,?,?,?,?,?,?,?,?,?)');$st->execute([$type,$title,$slug,$body,$status,$category,$categoryId?:null,$featuredImage,$seoTitle,$seoDescription]);$id=(int)$pdo->lastInsertId();}
   $success='تغییرات ذخیره شد.';$action='edit';
  }catch(PDOException $e){$error='ذخیره انجام نشد. ابتدا فایل upgrade-content-fields.sql را در phpMyAdmin اجرا کن. اگر قبلاً اجرا شده، نامک را بررسی کن.';}
 }
}
if(isset($_GET['deleted']))$success='محتوا حذف شد.';
$categories=$pdo->query('SELECT c.id,c.name,c.parent_id,p.name AS parent_name FROM post_categories c LEFT JOIN post_categories p ON p.id=c.parent_id ORDER BY p.name,c.name')->fetchAll();
if($action==='new'||$action==='edit'){
 $item=['id'=>0,'title'=>'','slug'=>'','body'=>'','status'=>'draft','category'=>'','category_id'=>null,'featured_image'=>'','seo_title'=>'','seo_description'=>''];
 if($action==='edit'&&$id){$st=$pdo->prepare('SELECT * FROM content_items WHERE id=? AND type=?');$st->execute([$id,$type]);$found=$st->fetch();if($found)$item=array_merge($item,$found);else{$action='list';$error='محتوا پیدا نشد.';}}
 if($action!=='list'){
 admin_header(($action==='new'?'افزودن ':'ویرایش ').$label,$type==='post'?'posts':'pages');page_heading(($action==='new'?'افزودن ':'ویرایش ').$label,'تصویر شاخص، دسته‌بندی و اطلاعات سئو را تنظیم کنید.','<a class="btn secondary" href="'.$file.'">بازگشت به فهرست</a>');if($success)notice($success);if($error)notice($error,true);
 echo '<form method="post" class="panel" style="margin-bottom:12px">';csrf_field();echo '<input type="hidden" name="do" value="add_category"><input type="hidden" name="return_action" value="'.h($action).'"><input type="hidden" name="id" value="'.(int)$item['id'].'"><div class="field"><label>ساخت دسته‌بندی در همین صفحه</label><input name="new_category_name" placeholder="نام دسته‌بندی"><select name="new_category_parent"><option value="0">بدون دسته مادر</option>';foreach($categories as $cat){echo '<option value="'.(int)$cat['id'].'">'.h(($cat['parent_name']?'— ':'').$cat['name']).'</option>';}echo '</select></div><button class="btn secondary">＋ ایجاد دسته‌بندی</button></form>';
 echo '<form class="panel" method="post" enctype="multipart/form-data">';csrf_field();echo '<input type="hidden" name="id" value="'.(int)$item['id'].'"><div class="field"><label>عنوان</label><input name="title" required maxlength="220" value="'.h((string)$item['title']).'"></div><div class="field"><label>نامک (URL)</label><input name="slug" maxlength="220" value="'.h((string)$item['slug']).'" placeholder="مثلاً راهنمای-شروع"></div>';
 echo '<div class="field"><label>محتوا</label><textarea name="body" rows="12">'.h((string)$item['body']).'</textarea></div>';
 echo '<div class="field"><label>دسته‌بندی</label><select name="category_id"><option value="">بدون دسته‌بندی</option>';foreach($categories as $cat){echo '<option value="'.(int)$cat['id'].'" '.(((int)($item['category_id']??0)===(int)$cat['id'])?'selected':'').'>'.h(($cat['parent_name']?'— ':'').$cat['name']).'</option>';}echo '</select></div>';
 echo '<div class="field"><label>تصویر شاخص</label><input type="file" name="featured_image" accept="image/jpeg,image/png,image/webp,image/gif"><input type="hidden" name="featured_image_existing" value="'.h((string)($item['featured_image']??'')).'"><small class="muted">JPG، PNG، WebP یا GIF؛ حداکثر ۵ مگابایت.</small>';
 if(!empty($item['featured_image'])) echo '<p><img src="../'.h(ltrim((string)$item['featured_image'],'/')).'" alt="" style="max-width:240px;max-height:150px;object-fit:cover;border-radius:10px"></p>';
 echo '</div><details class="field" open><summary>تنظیمات سئو</summary><div class="field"><label>عنوان سئو</label><input name="seo_title" maxlength="220" value="'.h((string)($item['seo_title']??'')).'" placeholder="در صورت خالی بودن، عنوان نوشته استفاده می‌شود."></div><div class="field"><label>توضیحات متا</label><textarea name="seo_description" rows="3" maxlength="320" placeholder="خلاصه‌ای کوتاه برای نتایج جست‌وجو">'.h((string)($item['seo_description']??'')).'</textarea></div></details>';
 echo '<div class="field"><label>وضعیت</label><select name="status"><option value="draft" '.($item['status']==='draft'?'selected':'').'>پیش‌نویس</option><option value="published" '.($item['status']==='published'?'selected':'').'>منتشرشده</option></select></div><button class="btn" name="do" value="save">ذخیره '.$label.'</button></form>';admin_footer();exit;
 }}
$st=$pdo->prepare('SELECT * FROM content_items WHERE type=? ORDER BY updated_at DESC');$st->execute([$type]);$items=$st->fetchAll();admin_header($label.'ها',$type==='post'?'posts':'pages');page_heading('مدیریت '.$label.'ها','محتواهای منتشرشده و پیش‌نویس‌ها را از اینجا مدیریت کنید.','<a class="btn" href="'.$file.'?action=new">＋ افزودن '.$label.'</a>');if($success)notice($success);if($error)notice($error,true);
echo '<style>
/* پیش‌نمایش تصویر فقط با رفتن نشانگر روی عنوان نوشته */
.admin-post-title-preview {
    position: relative;
    display: inline-block;
    cursor: help;
}
.admin-image-tooltip {
    display: none;
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    z-index: 99999;
    width: 280px;
    height: 190px;
    padding: 8px;
    background: #fff;
    border: 1px solid #d9dee8;
    border-radius: 10px;
    box-shadow: 0 10px 30px rgba(0,0,0,.2);
    box-sizing: border-box;
    pointer-events: none;
}
.admin-image-tooltip img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: contain;
    border-radius: 6px;
}
.admin-post-title-preview:hover .admin-image-tooltip,
.admin-post-title-preview:focus .admin-image-tooltip,
.admin-post-title-preview:focus-within .admin-image-tooltip {
    display: block;
}
@media (max-width: 600px) {
    .admin-image-tooltip {
        width: 220px;
        height: 155px;
    }
}
</style>';
echo '<section class="panel"><div class="table-wrap"><table class="table"><thead><tr><th>عنوان</th><th>دسته‌بندی</th><th>وضعیت</th><th>آخرین ویرایش</th><th>عملیات</th></tr></thead><tbody>';if(!$items)echo '<tr><td colspan="5" class="empty">هنوز '.$label.'ی ثبت نشده است. از دکمه افزودن شروع کنید.</td></tr>';foreach($items as $it){echo '<tr><td><strong class="admin-post-title-preview" tabindex="0">'.h($it['title']); if($type==='post'&&!empty($it['featured_image'])) echo '<span class="admin-image-tooltip"><img src="../'.h(ltrim((string)$it['featured_image'],'/')).'" alt="پیش‌نمایش تصویر شاخص"></span>'; echo '</strong></td><td>'.h((string)($it['category']??'')).'</td><td><span class="badge '.($it['status']==='published'?'':'off').'">'.($it['status']==='published'?'منتشرشده':'پیش‌نویس').'</span></td><td>'.h($it['updated_at']).'</td><td><div class="actions"><a href="'.$file.'?action=edit&id='.(int)$it['id'].'">ویرایش</a><form method="post" class="inline" onsubmit="return confirm(\'این مورد حذف شود؟\')">';csrf_field();echo '<input type="hidden" name="id" value="'.(int)$it['id'].'"><button class="btn danger small" name="do" value="delete">حذف</button></form></div></td></tr>'; }echo '</tbody></table></div></section>';admin_footer();
