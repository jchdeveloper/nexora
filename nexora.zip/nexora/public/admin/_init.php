<?php
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/app/Core/bootstrap.php';
use App\Core\Database;
use App\Core\Security;
Security::requireAdmin();
$pdo = Database::connection();
function h(mixed $v): string { return Security::e($v); }
function ensure_admin_tables(PDO $pdo): void {
 $sqls = [
 "CREATE TABLE IF NOT EXISTS content_items (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, type ENUM('post','page') NOT NULL, title VARCHAR(220) NOT NULL, slug VARCHAR(220) NOT NULL, body MEDIUMTEXT NULL, status ENUM('draft','published') NOT NULL DEFAULT 'draft', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE KEY unique_type_slug(type,slug)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS media (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, filename VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL, mime_type VARCHAR(100) NOT NULL, uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS site_menus (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, label VARCHAR(120) NOT NULL, url VARCHAR(255) NOT NULL, sort_order INT NOT NULL DEFAULT 0, is_active TINYINT(1) NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS comments (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, author VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL DEFAULT '', body TEXT NOT NULL, status ENUM('pending','approved','spam') NOT NULL DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS page_views (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, path VARCHAR(255) NOT NULL, viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX viewed_at_idx(viewed_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
 ]; foreach($sqls as $sql) $pdo->exec($sql);
}
ensure_admin_tables($pdo);
require_once dirname(__DIR__).'/section-schema.php';
nexora_section_schema($pdo);
function admin_header(string $title, string $active='dashboard'): void {
 $items=[['dashboard','▦','پیشخوان','index.php'],['posts','▤','نوشته‌ها','posts.php'],['pages','▧','برگه‌ها','pages.php'],['media','▧','رسانه‌ها','media.php'],['comments','☷','دیدگاه‌ها','comments.php'],['menus','☰','فهرست‌ها','menus.php'],['sections','▦','مدیریت سکشن‌ها','sections.php'],['social-networks','◎','شبکه‌های اجتماعی','social-networks.php'],['appearance','✦','نمایش و ظاهر','appearance.php'],['users','♙','کاربران','users.php'],['analytics','▥','آمار بازدید','analytics.php'],['settings','⚙','تنظیمات','settings.php']];
 echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).' — Nexora</title><link rel="stylesheet" href="../assets/css/admin.css"><link rel="stylesheet" href="../assets/css/admin-vazir-local.css"></head><body><div class="admin-shell"><aside class="sidebar" id="sidebar"><div class="brand"><span class="brand-mark">N</span><div><strong>Nexora</strong><small>مدیریت وب‌سایت</small></div></div><div><div class="nav-label">مدیریت محتوا</div><nav class="admin-nav">';
 foreach($items as [$key,$icon,$label,$url]) { if(in_array($key,['settings','users','analytics','appearance','social-networks'])) continue; echo '<a class="'.($active===$key?'active':'').'" href="'.$url.'"><span class="nav-icon">'.$icon.'</span>'.h($label).'</a>'; }
 echo '</nav><div class="nav-label">مدیریت سایت</div><nav class="admin-nav">'; foreach($items as [$key,$icon,$label,$url]) { if(!in_array($key,['appearance','users','analytics','settings','social-networks'])) continue; echo '<a class="'.($active===$key?'active':'').'" href="'.$url.'"><span class="nav-icon">'.$icon.'</span>'.h($label).'</a>'; }
 echo '</nav></div><div class="sidebar-bottom"><nav class="admin-nav"><a href="../index.php" target="_blank"><span class="nav-icon">↗</span>مشاهده سایت</a><a href="logout.php"><span class="nav-icon">⇥</span>خروج از حساب</a></nav></div></aside><div class="main-area"><header class="topbar"><div class="topbar-actions"><button class="mobile-menu" onclick="document.getElementById(\'sidebar\').classList.toggle(\'open\')" aria-label="منو">☰</button><span class="topbar-title">'.h($title).'</span></div><div class="topbar-actions"><a class="view-site" href="../index.php" target="_blank">مشاهده سایت ↗</a><div class="user-chip"><span class="avatar">'.h(mb_substr((string)($_SESSION['admin_username']??'م'),0,1,'UTF-8')).'</span><span>'.h((string)($_SESSION['admin_username']??'مدیر سایت')).'</span></div></div></header><main class="content">';
}
function admin_footer(): void { echo '</main></div></div></body></html>'; }
function csrf_field(): void { echo '<input type="hidden" name="_csrf" value="'.h(Security::csrfToken()).'">'; }
function notice(string $message, bool $danger=false): void { echo '<div class="notice'.($danger?' danger':'').'">'.h($message).'</div>'; }
function page_heading(string $title,string $desc='',string $action=''): void { echo '<div class="page-heading"><div><h1>'.h($title).'</h1><p>'.h($desc).'</p></div>'.$action.'</div>'; }
