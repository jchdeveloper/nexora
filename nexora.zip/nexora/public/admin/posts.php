<?php
$contentType='post'; require __DIR__.'/content-manager.php';
