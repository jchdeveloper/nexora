<?php
require_once __DIR__.'/_init.php';
$success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 \App\Core\Security::verifyCsrf(); $action=(string)($_POST['action']??'');
 if($action==='toggle'){$id=(int)($_POST['id']??0);$q=$pdo->prepare('UPDATE sections SET is_active=1-is_active WHERE id=?');$q->execute([$id]);$success='وضعیت سکشن تغییر کرد.';}
 elseif($action==='order'){$orders=$_POST['order']??[];if(is_array($orders)){foreach($orders as $id=>$n){$q=$pdo->prepare('UPDATE sections SET sort_order=? WHERE id=?');$q->execute([max(1,min(9999,(int)$n)),(int)$id]);}$success='ترتیب ذخیره شد.';}}
}
$rows=$pdo->query('SELECT * FROM sections ORDER BY sort_order,id')->fetchAll(); admin_header('مدیریت سکشن‌ها','sections');
if($success)notice($success);
page_heading('مدیریت سکشن‌ها','ساخت و تنظیم سکشن‌های صفحه اصلی بدون ویرایش کد.');
echo '<div class="panel"><p><a class="btn" href="create-section.php">＋ افزودن سکشن جدید</a></p><div style="overflow:auto"><table class="table"><thead><tr><th>ترتیب</th><th>عنوان</th><th>نوع</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>';
$labels=['posts'=>'آخرین نوشته‌ها','text'=>'متن و تصویر','services'=>'خدمات/ویژگی‌ها','cards'=>'کارت‌های چندتایی','gallery'=>'گالری','stats'=>'آمار','testimonials'=>'نظرات','faq'=>'سؤالات متداول','contact'=>'فرم تماس','html'=>'HTML سفارشی'];
foreach($rows as $r){echo '<tr><td>'.(int)$r['sort_order'].'</td><td><strong>'.h($r['title']).'</strong><br><small>'.h($r['section_key']).'</small></td><td>'.h($labels[$r['section_type']??'text']??'متن').'</td><td>'.($r['is_active']?'فعال':'مخفی').'</td><td><a href="section-editor.php?id='.(int)$r['id'].'">ویرایش</a> · <form class="inline" method="post">';csrf_field();echo '<input type="hidden" name="id" value="'.(int)$r['id'].'"><button class="btn" name="action" value="toggle">'.($r['is_active']?'مخفی‌سازی':'بازیابی').'</button></form></td></tr>';}
echo '</tbody></table></div></div><div class="panel"><h2>مرتب‌سازی</h2><form method="post">';csrf_field();echo '<input type="hidden" name="action" value="order">';foreach($rows as $r)echo '<div class="field"><label>'.h($r['title']).'</label><input type="number" min="1" name="order['.(int)$r['id'].']" value="'.(int)$r['sort_order'].'"></div>';echo '<button class="btn">ذخیره ترتیب</button></form></div>';admin_footer();
