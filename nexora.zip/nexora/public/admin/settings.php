<?php
require_once __DIR__.'/_init.php';$success='';
$fields=[['brand_name','نام برند','text'],['tagline','شعار کوتاه','text'],['accent_color','رنگ اصلی برند','color'],['secondary_color','رنگ مکمل برند','color'],['background_color','رنگ پس‌زمینه سایت','color'],['email','ایمیل','email'],['phone','تلفن','text'],['address','نشانی','text'],['chat_button_color','رنگ دکمه شروع گفتگو','color'],['chat_button_gradient_start','رنگ اول گرادیانت دکمه گفتگو','color'],['chat_button_gradient_end','رنگ دوم گرادیانت دکمه گفتگو','color']];
$socials=['instagram'=>'اینستاگرام','linkedin'=>'لینکدین','telegram'=>'تلگرام','rubika'=>'روبیکا','eitaa'=>'ایتا','bale'=>'بله','whatsapp'=>'واتساپ','youtube'=>'یوتیوب','aparat'=>'آپارات','x'=>'ایکس (توییتر)'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 \App\Core\Security::verifyCsrf();
 if(($_POST['action']??'')==='reset_all_section_backgrounds'){
   $pdo->beginTransaction();
   try {
     $pdo->exec("UPDATE sections SET background_color='#c7fff8'");
     foreach($pdo->query('SELECT id,section_data FROM sections') as $sec){$d=json_decode((string)$sec['section_data'],true);if(!is_array($d))$d=[];$d['gradient_color_1']='#c7fff8';$d['gradient_color_2']='#c7fff8';$d['gradient_color_3']='';$d['use_gradient_color_3']=0;$q=$pdo->prepare('UPDATE sections SET section_data=? WHERE id=?');$q->execute([json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),(int)$sec['id']]);}
     $pdo->commit();$success='پس‌زمینه همه سکشن‌ها به رنگ اصلی #c7fff8 بازنشانی شد.';
   } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$success='بازنشانی انجام نشد؛ بکاپ و ساختار دیتابیس را بررسی کنید.';}
 } else {
 $vals=[];foreach($fields as [$key,$label,$type])$vals[$key]=trim((string)($_POST[$key]??''));
 foreach(['accent_color'=>'#ff6b35','secondary_color'=>'#7c5cff','background_color'=>'#c7fff8','chat_button_color'=>'#ff6b35','chat_button_gradient_start'=>'#ff6b35','chat_button_gradient_end'=>'#7c5cff'] as $k=>$fallback)if(!preg_match('/^#[0-9a-fA-F]{6}$/',$vals[$k]))$vals[$k]=$fallback;
 foreach($socials as $key=>$label){$v=trim((string)($_POST['social_'.$key]??''));$vals['social_'.$key]=mb_substr($v,0,255,'UTF-8');}
 $stmt=$pdo->prepare('INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');foreach($vals as $key=>$value)$stmt->execute([$key,$value]);$success='تنظیمات با موفقیت ذخیره شد.';
 }
}
$settings=[];foreach($pdo->query('SELECT setting_key,setting_value FROM settings') as $r)$settings[$r['setting_key']]=$r['setting_value'];
admin_header('تنظیمات سایت','settings');if($success)notice($success);page_heading('تنظیمات سایت','هویت بصری، دکمه گفتگو و شبکه‌های اجتماعی را مدیریت کنید.');
echo '<form method="post" class="panel">';csrf_field();echo '<h2>اطلاعات و رنگ‌های سایت</h2><div class="grid">';foreach($fields as [$key,$label,$type])echo '<div class="field"><label for="'.h($key).'">'.h($label).'</label><input id="'.h($key).'" name="'.h($key).'" type="'.h($type).'" value="'.h($settings[$key]??match($key){'accent_color','chat_button_color','chat_button_gradient_start'=>'#ff6b35','secondary_color','chat_button_gradient_end'=>'#7c5cff','background_color'=>'#c7fff8',default=>''}).'" '.($key==='brand_name'?'required':'').'></div>';echo '</div><h2>پیوند شبکه‌های اجتماعی</h2><p class="muted">در حالت معمول فقط نام کاربری را وارد کن؛ اگر شبکه لینک اختصاصی متفاوتی دارد، می‌توانی آدرس کامل https:// را وارد کنی. خالی گذاشتن فیلد، آن شبکه را از فوتر پنهان می‌کند.</p><div class="grid">';foreach($socials as $key=>$label)echo '<div class="field"><label for="social_'.$key.'">'.h($label).' — نام کاربری یا لینک کامل</label><input id="social_'.$key.'" name="social_'.$key.'" type="text" value="'.h($settings['social_'.$key]??'').'" placeholder="نام‌کاربری"></div>';echo '</div><button class="btn" type="submit">ذخیره تنظیمات</button></form><form method="post" class="panel" onsubmit="return confirm(\'پس‌زمینه تمام سکشن‌ها به #c7fff8 تغییر کند؟ گرادیانت‌های اختصاصی نیز بازنشانی می‌شوند.\')">';csrf_field();echo '<input type="hidden" name="action" value="reset_all_section_backgrounds"><h2>بازنشانی رنگ سکشن‌ها</h2><p class="muted">با این دکمه، پس‌زمینه همه سکشن‌ها به رنگ اصلی سایت یعنی <code>#c7fff8</code> تغییر می‌کند و گرادیانت‌های اختصاصی آن‌ها پاک می‌شوند. رنگ‌های متن و محتوای سکشن‌ها تغییر نمی‌کنند.</p><button class="btn btn-secondary" type="submit">بازنشانی پس‌زمینه همه سکشن‌ها</button></form>';admin_footer();
