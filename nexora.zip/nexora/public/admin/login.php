<?php
declare(strict_types=1);
require_once dirname(__DIR__,2).'/app/Core/bootstrap.php';
use App\Core\Database; use App\Core\Security;
if(!empty($_SESSION['admin_id'])){header('Location: index.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 Security::verifyCsrf(); $email=trim((string)($_POST['email']??'')); $password=(string)($_POST['password']??'');
 try { $stmt=Database::connection()->prepare('SELECT id,name,email,password_hash FROM admins WHERE email=? LIMIT 1'); $stmt->execute([$email]); $admin=$stmt->fetch(); }
 catch(Throwable $e) { $stmt=Database::connection()->prepare('SELECT id,username AS name,username AS email,password_hash FROM admins WHERE username=? LIMIT 1'); $stmt->execute([$email]); $admin=$stmt->fetch(); }
 if($admin&&password_verify($password,$admin['password_hash'])){session_regenerate_id(true);$_SESSION['admin_id']=$admin['id'];$_SESSION['admin_username']=$admin['name'];header('Location: index.php');exit;}
 $error='ایمیل یا رمز عبور صحیح نیست.';
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود مدیریت Nexora</title><link rel="stylesheet" href="../assets/css/admin.css"></head><body><main class="login-box"><div class="login-logo"><span class="brand-mark">N</span><div><strong>Nexora</strong><div class="muted">پنل مدیریت</div></div></div><h1>خوش آمدید 👋</h1><p class="muted">برای ورود به پیشخوان، اطلاعات خود را وارد کنید.</p><?php if($error):?><div class="notice danger"><?=Security::e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="_csrf" value="<?=Security::e(Security::csrfToken())?>"><div class="field"><label for="email">ایمیل مدیر</label><input id="email" type="email" name="email" autocomplete="username" required></div><div class="field"><label for="password">رمز عبور</label><input id="password" type="password" name="password" autocomplete="current-password" required></div><button class="btn" type="submit">ورود به پیشخوان</button></form></main></body></html>