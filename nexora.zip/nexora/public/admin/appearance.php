<?php
declare(strict_types=1);
require_once __DIR__.'/_init.php';
$message=''; $danger=false;
$settings=[]; foreach($pdo->query('SELECT setting_key,setting_value FROM settings') as $r)$settings[$r['setting_key']]=$r['setting_value'];
function appearance_save(PDO $pdo, string $key, string $value): void { $st=$pdo->prepare('INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)'); $st->execute([$key,$value]); }
function appearance_hex(array $rgb): string { return sprintf('#%02x%02x%02x', max(0,min(255,$rgb[0])),max(0,min(255,$rgb[1])),max(0,min(255,$rgb[2]))); }
function appearance_logo_colors(string $path): array {
 if(!function_exists('imagecreatefromstring')) return [];
 $raw=@file_get_contents($path); if($raw===false)return []; $im=@imagecreatefromstring($raw); if(!$im)return [];
 $w=imagesx($im);$h=imagesy($im);$step=max(1,(int)floor(max($w,$h)/100));$hist=[];
 for($y=0;$y<$h;$y+=$step){for($x=0;$x<$w;$x+=$step){$c=imagecolorat($im,$x,$y);$a=($c & 0x7F000000)>>24;if($a>100)continue;$r=($c>>16)&255;$g=($c>>8)&255;$b=$c&255;if(max($r,$g,$b)>245&&min($r,$g,$b)>225)continue;if(max($r,$g,$b)<28)continue;$key=sprintf('#%02x%02x%02x',(int)(round($r/24)*24),(int)(round($g/24)*24),(int)(round($b/24)*24));$hist[$key]=($hist[$key]??0)+1;}}
 imagedestroy($im);arsort($hist);$out=[];foreach(array_keys($hist) as $hex){$out[]=$hex;if(count($out)>=2)break;}return $out;
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 \App\Core\Security::verifyCsrf();
 $brand=trim((string)($_POST['brand_name']??'Nexora'));
 $colors=['accent_color'=>(string)($_POST['accent_color']??'#ff6b35'),'secondary_color'=>(string)($_POST['secondary_color']??'#7c5cff'),'background_color'=>(string)($_POST['background_color']??'#090909')];
 foreach($colors as $k=>$v) if(!preg_match('/^#[0-9a-fA-F]{6}$/',$v)) $colors[$k]=['accent_color'=>'#ff6b35','secondary_color'=>'#7c5cff','background_color'=>'#090909'][$k];
 $uploadDir=dirname(__DIR__).'/uploads/branding'; if(!is_dir($uploadDir)) @mkdir($uploadDir,0755,true);
 $uploaded=[];
 foreach(['logo'=>'لوگو','favicon'=>'فاوآیکون'] as $field=>$label){
  if(empty($_FILES[$field]['name']) || !isset($_FILES[$field]['tmp_name']) || !is_uploaded_file($_FILES[$field]['tmp_name'])) continue;
  if((int)$_FILES[$field]['size']>3*1024*1024){$message="$label باید کمتر از ۳ مگابایت باشد.";$danger=true;break;}
  $info=@getimagesize($_FILES[$field]['tmp_name']);$mime=$info['mime']??'';$ext=match($mime){'image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp','image/gif'=>'gif',default=>''};
  if($ext===''){$message="فرمت $label معتبر نیست؛ PNG، JPG، WEBP یا GIF انتخاب کنید.";$danger=true;break;}
  $name=$field.'-'.bin2hex(random_bytes(12)).'.'.$ext;$dest=$uploadDir.'/'.$name;
  if(!move_uploaded_file($_FILES[$field]['tmp_name'],$dest)){$message="بارگذاری $label انجام نشد.";$danger=true;break;}
  $uploaded[$field]='uploads/branding/'.$name;
 }
 if(!$danger){
  appearance_save($pdo,'brand_name',$brand!==''?$brand:'Nexora');appearance_save($pdo,'header_brand_mode', (($_POST['header_brand_mode']??'logo')==='name'?'name':'logo'));foreach($colors as $k=>$v)appearance_save($pdo,$k,$v);
  foreach($uploaded as $k=>$v)appearance_save($pdo,$k.'_path',$v);
  if(isset($uploaded['logo']) && !isset($uploaded['favicon'])) appearance_save($pdo,'favicon_path',$uploaded['logo']);
  if(isset($_POST['extract_colors']) && isset($uploaded['logo'])){ $found=appearance_logo_colors($uploadDir.'/'.basename($uploaded['logo'])); if($found){appearance_save($pdo,'accent_color',$found[0]);appearance_save($pdo,'secondary_color',$found[1]??$found[0]);} }
  $settings=[];foreach($pdo->query('SELECT setting_key,setting_value FROM settings') as $r)$settings[$r['setting_key']]=$r['setting_value'];
  $message=isset($_POST['extract_colors'])?'لوگو بارگذاری شد و رنگ‌های پیشنهادی استخراج شدند؛ در صورت نیاز رنگ‌ها را تنظیم و دوباره ذخیره کنید.':'تنظیمات هویت بصری ذخیره شد.';
 }
}
$settings=[];foreach($pdo->query('SELECT setting_key,setting_value FROM settings') as $r)$settings[$r['setting_key']]=$r['setting_value'];
admin_header('نمایش و ظاهر','appearance');page_heading('هویت بصری شرکت','لوگو و رنگ‌های سازمانی قالب را از همین صفحه مدیریت کنید.');if($message)notice($message,$danger);
$logo=(string)($settings['logo_path']??'');$favicon=(string)($settings['favicon_path']??$logo);
echo '<section class="panel"><h2>لوگو و رنگ‌بندی</h2><form method="post" enctype="multipart/form-data">';csrf_field();
echo '<div class="field"><label for="brand_name">نام شرکت / برند</label><input id="brand_name" name="brand_name" maxlength="120" value="'.h($settings['brand_name']??'Nexora').'" required></div>';
echo '<div class="field"><label>نمایش برند در سمت راست منوی بالای سایت</label><label><input type="radio" name="header_brand_mode" value="logo"'.(($settings['header_brand_mode']??'logo')==='logo'?' checked':'').'> نمایش لوگو</label> <label><input type="radio" name="header_brand_mode" value="name"'.(($settings['header_brand_mode']??'logo')==='name'?' checked':'').'> نمایش نام سایت به‌جای لوگو</label></div>';
echo '<div class="grid"><div class="field"><label for="logo">لوگوی شرکت (PNG، JPG، WEBP یا GIF؛ حداکثر ۳ مگابایت)</label><input id="logo" type="file" name="logo" accept="image/png,image/jpeg,image/webp,image/gif">';if($logo!=='')echo '<p><img src="../'.h($logo).'" alt="لوگوی فعلی" style="max-width:220px;max-height:100px;object-fit:contain;background:#f4f4f4;padding:8px;border-radius:8px"></p>';echo '</div><div class="field"><label for="favicon">آیکون مرورگر (اختیاری؛ اگر انتخاب نشود از لوگو استفاده می‌شود)</label><input id="favicon" type="file" name="favicon" accept="image/png,image/jpeg,image/webp,image/gif">';if($favicon!=='')echo '<p><img src="../'.h($favicon).'" alt="فاوآیکون فعلی" style="width:40px;height:40px;object-fit:contain;background:#f4f4f4;padding:4px;border-radius:8px"></p>';echo '</div></div>';
echo '<div class="grid"><div class="field"><label for="accent_color">رنگ اصلی سازمانی</label><input id="accent_color" class="color-field" type="color" name="accent_color" value="'.h($settings['accent_color']??'#ff6b35').'" oninput="document.getElementById(\'accent_hex\').value=this.value"><input id="accent_hex" value="'.h($settings['accent_color']??'#ff6b35').'" maxlength="7" aria-label="کد رنگ اصلی" oninput="if(/^#[0-9a-fA-F]{6}$/.test(this.value))document.getElementById(\'accent_color\').value=this.value"></div>';
echo '<div class="field"><label for="secondary_color">رنگ مکمل</label><input id="secondary_color" class="color-field" type="color" name="secondary_color" value="'.h($settings['secondary_color']??'#7c5cff').'" oninput="document.getElementById(\'secondary_hex\').value=this.value"><input id="secondary_hex" value="'.h($settings['secondary_color']??'#7c5cff').'" maxlength="7" aria-label="کد رنگ مکمل" oninput="if(/^#[0-9a-fA-F]{6}$/.test(this.value))document.getElementById(\'secondary_color\').value=this.value"></div>';
echo '<div class="field"><label for="background_color">رنگ پس‌زمینه</label><input id="background_color" class="color-field" type="color" name="background_color" value="'.h($settings['background_color']??'#090909').'" oninput="document.getElementById(\'background_hex\').value=this.value"><input id="background_hex" value="'.h($settings['background_color']??'#090909').'" maxlength="7" aria-label="کد رنگ پس‌زمینه" oninput="if(/^#[0-9a-fA-F]{6}$/.test(this.value))document.getElementById(\'background_color\').value=this.value"></div></div>';
?>
<p class="muted">لوگو را انتخاب کنید و «استخراج رنگ از لوگو» را بزنید. رنگ‌های پیشنهادی پیش از ذخیره قابل ویرایش‌اند؛ سپس «ذخیره تنظیمات» را انتخاب کنید.</p>
<button class="btn" name="save_brand" value="1">ذخیره تنظیمات</button>
<button class="btn secondary" type="button" id="extract-logo-colors">استخراج رنگ از لوگو</button>
<span id="logo-color-status" class="muted" aria-live="polite"></span>
<a class="btn secondary" href="sections.php">مدیریت بخش‌های صفحه اصلی</a>
</form></section>
<script>
(function(){
 const btn=document.getElementById('extract-logo-colors');
 const input=document.getElementById('logo');
 const status=document.getElementById('logo-color-status');
 function setColor(id,hex){const el=document.getElementById(id);if(el)el.value=hex;const mirror=document.getElementById(id.replace('_color','_hex'));if(mirror)mirror.value=hex;}
 btn.addEventListener('click',function(){
  if(!input.files||!input.files[0]){status.textContent='ابتدا فایل لوگو را انتخاب کنید.';return;}
  const file=input.files[0];
  if(!/^image\/(png|jpeg|webp|gif)$/.test(file.type)){status.textContent='فرمت تصویر پشتیبانی نمی‌شود.';return;}
  const reader=new FileReader();
  reader.onload=function(){const img=new Image();img.onload=function(){try{
   const c=document.createElement('canvas');c.width=40;c.height=40;
   const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0,40,40);
   const data=ctx.getImageData(0,0,40,40).data;const hist={};
   for(let i=0;i<data.length;i+=4){const a=data[i+3],r=data[i],g=data[i+1],b=data[i+2];if(a<100||(Math.max(r,g,b)>245&&Math.min(r,g,b)>220)||Math.max(r,g,b)<28)continue;
    const rr=Math.min(255,Math.round(r/24)*24),gg=Math.min(255,Math.round(g/24)*24),bb=Math.min(255,Math.round(b/24)*24);
    const hex='#'+[rr,gg,bb].map(v=>v.toString(16).padStart(2,'0')).join('');hist[hex]=(hist[hex]||0)+1;
   }
   const ranked=Object.keys(hist).sort((a,b)=>hist[b]-hist[a]);
   if(!ranked.length){status.textContent='رنگ غالب قابل تشخیص نبود؛ رنگ‌ها را دستی انتخاب کنید.';return;}
   setColor('accent_color',ranked[0]);setColor('secondary_color',ranked.find(x=>x!==ranked[0])||ranked[0]);
   status.textContent='رنگ‌های پیشنهادی آماده‌اند؛ پیش از ذخیره می‌توانید آن‌ها را تغییر دهید.';
  }catch(e){status.textContent='استخراج رنگ انجام نشد؛ رنگ‌ها را دستی انتخاب کنید.';}};img.onerror=function(){status.textContent='خواندن تصویر ممکن نشد.';};img.src=reader.result;};reader.readAsDataURL(file);
 });
})();
</script>
<?php
admin_footer();
