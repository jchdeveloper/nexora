<?php
require_once __DIR__.'/_init.php';

$message = '';
$danger = false;
$editItem = null;

function menu_url_is_safe(string $url): bool {
    $url = trim($url);
    if ($url === '' || preg_match('/^\s*(javascript|data|vbscript):/i', $url)) return false;
    return (bool)preg_match('~^(#|/|https?://|mailto:|tel:|[A-Za-z0-9_.-]+(?:[/?#][^\s]*)?)~i', $url);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    \App\Core\Security::verifyCsrf();
    $act = (string)($_POST['action'] ?? 'save');

    if ($act === 'save_cta') {
        $ctaText = trim((string)($_POST['header_cta_text'] ?? ''));
        $ctaUrl = trim((string)($_POST['header_cta_url'] ?? ''));
        if ($ctaText === '' || !menu_url_is_safe($ctaUrl)) {
            $message = 'متن دکمه و نشانی معتبر وارد کنید.';
            $danger = true;
        } else {
            foreach (['header_cta_text' => $ctaText, 'header_cta_url' => $ctaUrl] as $key => $value) {
                $check = $pdo->prepare('SELECT setting_key FROM settings WHERE setting_key=? LIMIT 1');
                $check->execute([$key]);
                if ($check->fetchColumn()) {
                    $st = $pdo->prepare('UPDATE settings SET setting_value=? WHERE setting_key=?');
                    $st->execute([$value, $key]);
                } else {
                    $st = $pdo->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)');
                    $st->execute([$key, $value]);
                }
            }
            $message = 'تنظیمات دکمه هدر ذخیره شد.';
        }
    } elseif ($act === 'delete') {
        $st = $pdo->prepare('DELETE FROM site_menus WHERE id=?');
        $st->execute([(int)($_POST['id'] ?? 0)]);
        $message = 'پیوند حذف شد.';
    } elseif ($act === 'toggle') {
        $st = $pdo->prepare('UPDATE site_menus SET is_active=1-is_active WHERE id=?');
        $st->execute([(int)($_POST['id'] ?? 0)]);
        $message = 'وضعیت پیوند تغییر کرد.';
    } else {
        $id = (int)($_POST['id'] ?? 0);
        $label = trim((string)($_POST['label'] ?? ''));
        $url = trim((string)($_POST['url'] ?? ''));
        $order = (int)($_POST['sort_order'] ?? 10);
        if ($label === '' || mb_strlen($label) > 120 || !menu_url_is_safe($url) || mb_strlen($url) > 255) {
            $message = 'عنوان و نشانی معتبر وارد کنید.';
            $danger = true;
        } else {
            if ($id > 0) {
                $st = $pdo->prepare('UPDATE site_menus SET label=?, url=?, sort_order=? WHERE id=?');
                $st->execute([$label, $url, $order, $id]);
                $message = 'پیوند ویرایش شد.';
            } else {
                $st = $pdo->prepare('INSERT INTO site_menus(label,url,sort_order) VALUES(?,?,?)');
                $st->execute([$label, $url, $order]);
                $message = 'پیوند منو اضافه شد.';
            }
        }
    }
}

if (isset($_GET['edit'])) {
    $st = $pdo->prepare('SELECT * FROM site_menus WHERE id=?');
    $st->execute([(int)$_GET['edit']]);
    $editItem = $st->fetch() ?: null;
}
$items = $pdo->query('SELECT * FROM site_menus ORDER BY sort_order, id')->fetchAll();
$settings = [];
try {
    foreach ($pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('header_cta_text','header_cta_url')") as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
} catch (Throwable $e) {}
admin_header('فهرست‌های سایت', 'menus');
page_heading('فهرست‌های سایت', 'پیوندهای منوی دلخواه خود را مدیریت کنید.');
if ($message) notice($message, $danger);
$val = static function($key, $default='') use ($editItem) {
    return h((string)($editItem[$key] ?? $default));
};
echo '<section class="panel"><h2>'.($editItem ? 'ویرایش پیوند' : 'افزودن پیوند').'</h2><form method="post">';
csrf_field();
echo '<input type="hidden" name="id" value="'.(int)($editItem['id'] ?? 0).'"><div class="grid"><div class="field"><label>عنوان</label><input name="label" required maxlength="120" value="'.$val('label').'" placeholder="مثلاً درباره ما"></div><div class="field"><label>نشانی (URL)</label><input name="url" required maxlength="255" value="'.$val('url').'" placeholder="#about یا https://example.com"></div></div><div class="field"><label>ترتیب نمایش</label><input type="number" name="sort_order" value="'.$val('sort_order', '10').'"></div><button class="btn" name="action" value="save">'.($editItem ? 'ذخیره تغییرات' : 'افزودن به فهرست').'</button> ';
if ($editItem) echo '<a class="btn secondary" href="menus.php">لغو ویرایش</a>';
echo '</form></section>';
echo '<section class="panel"><h2>دکمه هدر</h2><p>متن و مقصد دکمه سمت هدر را جدا از لینک‌های منو تنظیم کنید.</p><form method="post">';
csrf_field();
echo '<div class="grid"><div class="field"><label>متن دکمه</label><input name="header_cta_text" maxlength="120" required value="'.h((string)($settings['header_cta_text'] ?? 'شروع گفتگو ↗')).'"></div><div class="field"><label>نشانی دکمه</label><input name="header_cta_url" maxlength="255" required value="'.h((string)($settings['header_cta_url'] ?? '#contact')).'"></div></div><button class="btn" name="action" value="save_cta">ذخیره دکمه هدر</button></form></section>';
echo '<section class="panel"><h2>پیوندهای فعلی</h2><div class="table-wrap"><table class="table"><thead><tr><th>عنوان</th><th>نشانی</th><th>ترتیب</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>';
if (!$items) echo '<tr><td colspan="5" class="empty">هنوز پیوندی اضافه نشده است.</td></tr>';
foreach ($items as $it) {
    echo '<tr><td>'.h($it['label']).'</td><td>'.h($it['url']).'</td><td>'.(int)$it['sort_order'].'</td><td><span class="badge '.($it['is_active'] ? '' : 'off').'">'.($it['is_active'] ? 'فعال' : 'غیرفعال').'</span></td><td><div class="actions">';
    echo '<a class="btn secondary small" href="menus.php?edit='.(int)$it['id'].'">ویرایش</a><form method="post">';
    csrf_field();
    echo '<input type="hidden" name="id" value="'.(int)$it['id'].'"><button class="btn secondary small" name="action" value="toggle">'.($it['is_active'] ? 'غیرفعال' : 'فعال').'</button></form><form method="post" onsubmit="return confirm(\'حذف شود؟\')">';
    csrf_field();
    echo '<input type="hidden" name="id" value="'.(int)$it['id'].'"><button class="btn danger small" name="action" value="delete">حذف</button></form></div></td></tr>';
}
echo '</tbody></table></div></section>';
admin_footer();
