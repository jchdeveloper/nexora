/* تعاملات و انیمیشن‌های سایت؛ توضیحات به فارسی */ 
const menuButton=document.querySelector('.menu-toggle');
const nav=document.querySelector('.main-nav');
menuButton?.addEventListener('click',()=>{const open=nav.classList.toggle('is-open');menuButton.setAttribute('aria-expanded',String(open));});
nav?.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener('click',event=>{
 const id=link.getAttribute('href'),target=id?document.querySelector(id):null;
 nav.classList.remove('is-open');menuButton?.setAttribute('aria-expanded','false');
 if(!target)return;event.preventDefault();
 if(window.lenisInstance)window.lenisInstance.scrollTo(target,{offset:-100,duration:0.3});
 else window.scrollTo({top:target.getBoundingClientRect().top+scrollY-(document.querySelector('.site-header')?.offsetHeight||80)-12,behavior:'smooth'});
 history.replaceState(null,'',id);
}));
document.querySelector('#year')?.append(String(new Date().getFullYear()));
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
if(!reduce&&window.gsap){if(window.ScrollTrigger)gsap.registerPlugin(ScrollTrigger);gsap.from('.hero .eyebrow,.hero h1,.hero .lead,.hero .button',{y:22,opacity:0,duration:.8,stagger:.1,ease:'power3.out'});if(window.ScrollTrigger)gsap.utils.toArray('.reveal').forEach(el=>{if(el.closest('.hero'))return;gsap.from(el,{y:26,opacity:0,duration:.7,scrollTrigger:{trigger:el,start:'top 88%',once:true}})});gsap.to('.orb-one',{scale:1.08,duration:3,yoyo:true,repeat:-1,ease:'sine.inOut'});}
if(!reduce&&window.Lenis){const lenis=new Lenis({duration:0.3,smoothWheel:true,anchors:false});window.lenisInstance=lenis;const raf=t=>{lenis.raf(t);requestAnimationFrame(raf)};requestAnimationFrame(raf);if(window.ScrollTrigger)lenis.on('scroll',ScrollTrigger.update);}
