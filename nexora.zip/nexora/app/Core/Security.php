<?php
declare(strict_types=1);

namespace App\Core;

final class Security
{
    public static function startSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            $cfg = require dirname(__DIR__, 2) . '/config/config.php';
            session_name($cfg['app']['session_name']);
            session_set_cookie_params([
                'httponly' => true,
                'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
                'samesite' => 'Lax',
            ]);
            session_start();
        }
    }

    public static function csrfToken(): string
    {
        self::startSession();
        if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
        return $_SESSION['_csrf'];
    }

    public static function verifyCsrf(): void
    {
        self::startSession();
        $sent = $_POST['_csrf'] ?? '';
        if (!is_string($sent) || !hash_equals($_SESSION['_csrf'] ?? '', $sent)) {
            http_response_code(419);
            exit('درخواست معتبر نیست. صفحه را تازه‌سازی کنید.');
        }
    }

    public static function e(mixed $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function requireAdmin(): void
    {
        self::startSession();
        if (empty($_SESSION['admin_id'])) {
            header('Location: login.php');
            exit;
        }
    }
}
