<?php
declare(strict_types=1);

namespace App\Core;

final class DateHelper
{
    public static function jalali(?string $datetime, bool $withTime = true): string
    {
        if (!$datetime) return '—';
        try { $dt = new \DateTimeImmutable($datetime); } catch (\Throwable $e) { return $datetime; }
        [$jy, $jm, $jd] = self::gregorianToJalali((int)$dt->format('Y'), (int)$dt->format('n'), (int)$dt->format('j'));
        $date = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
        return $withTime ? $date . ' - ' . $dt->format('H:i') : $date;
    }

    private static function gregorianToJalali(int $gy, int $gm, int $gd): array
    {
        $gdm = [0,31,($gy%4===0 && $gy%100!==0)||$gy%400===0?29:28,31,30,31,30,31,31,30,31,30,31];
        $gy2 = $gm > 2 ? $gy + 1 : $gy;
        $days = 355666 + 365*$gy + intdiv($gy2+3,4) - intdiv($gy2+99,100) + intdiv($gy2+399,400) + $gd;
        for ($i=1; $i<$gm; $i++) $days += $gdm[$i];
        $jy = -1595 + 33*intdiv($days,12053); $days %= 12053;
        $jy += 4*intdiv($days,1461); $days %= 1461;
        if ($days > 365) { $jy += intdiv($days-1,365); $days = ($days-1)%365; }
        if ($days < 186) { $jm = 1 + intdiv($days,31); $jd = 1 + $days%31; }
        else { $jm = 7 + intdiv($days-186,30); $jd = 1 + ($days-186)%30; }
        return [$jy,$jm,$jd];
    }
}
